#!/bin/bash

# 填写待校验的日志集合，带模块格式
# 注意，如果编码不能支持汉字，可以先使用字符编码转换
# iconv ./target_file.csv -f GBK -t UTF8 -o output_file
# 此集合中，方括号需要进行两次转义"\\["，而圆括号不需要转义"("

from_file="./rd.csv"

# 填写需要校验的目标代码目录位置
target_dir="."

let i=0

while read aline
do
    let i=$i+1
    printf "$i : "

    # 0 . 跳过首行标题
    if [[ $i -eq 1 ]];  then
        printf "\tskip title!\n"
        continue
    fi

<<"zzzz"
    # 测试使用，限制次数
    if [[ $i -eq 5 ]]; then
    break
    fi
zzzz

    # 1.  获取模块名
    # (依赖前提：模块名在第三列，并且是以日志名 XXX_log的形式存在)
    # ${字符串//pattern/替换为}
    arr=(${aline//,/ })
    arr_mod=(${arr[2]//_/ })
    # 切割出模块名
    module=${arr_mod[0]}
    # 大写转小写
    module=$(echo $module | tr '[A-Z]' '[a-z]')
    #printf "$module"
    #printf "\t"

    # 2. 获取日志内容
    # (依赖前提：输入csv满足如果内容存在逗号则此域一定有引号标示，
    # 并且日志是第一个存在引号的域，日志存在于第四列)
    log=`echo $aline | awk -F\"  '{print $2}'`
    if [[ -z "$log" ]]; then
        log=`echo $aline | awk -F,  '{print $4}'`
    fi
    #printf "$log\n"

    # 如果模块为空则给出输出提示
    if [[ -z "$module" ]]; then
        printf "$module"
        printf "\t"
        printf "module empty!(csv not module)\n"
        continue
    fi

    # 查找对应的模块路径
    dir=`find $target_dir -name $module -type d`
    if [[ -z "$dir" ]]; then
        printf "$module"
        printf "\t"
        printf "module dir not found!\n"
        continue
    fi

    # 在指定路径中搜索日志内容
    re=`grep -R "$log" $dir/src`
    if [[ -z "$re" ]]; then
        printf "$module"
        printf "\t"
        printf "[NF]\t"
        printf "$log\n"
        continue
    fi

    printf "$module"
    printf "\t"
    printf "[OK!]"
    #printf "$log"
    printf "\n"

<<"zzzz"
zzzz

done < $from_file

