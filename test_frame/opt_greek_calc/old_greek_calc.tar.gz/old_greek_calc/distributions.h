#ifndef DISTRIBUTIONS_H
#define DISTRIBUTIONS_H
#define  Pi  3.14159265358979
double NormCumDist(double Z);
double safe_ln(double x);
#endif
