#include <stdio.h>

struct greek_calc_input{
    // 下面七个是直接的输入
	char   call_put;
	double subject_price;
	double option_strike;
	double option_premium;
	int    now_date;
	int    expire_date;
	double no_risk_rate;
    // 时间参数是通过输入的两个日期来计算出来的
	double T;
    // 波动率是从上面六个输入中计算出来的
	double volatility;
};
