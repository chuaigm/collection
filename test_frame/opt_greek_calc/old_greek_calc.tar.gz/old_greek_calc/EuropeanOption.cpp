#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include "Option.h"
#include "distributions.h"
//del by jinchun 20130913 begin
//double ValueOpt(double p, double K, double sd, double rd, double rf, double t, int CP);
//del by jinchun 20130913 end
double DeltaOpt(double p, double K, double sd, double rd, double rf, double t, int CP);
double GammaOpt(double p, double K, double sd, double rd, double rf, double t, int CP);
double ThetaOpt(double p, double K, double sd, double rd, double rf, double t, int CP);
double RhoDomOpt(double p, double K, double sd, double rd, double rf, double t, int CP);
double RhoForOpt(double p, double K, double sd, double rd, double rf, double t, int CP);
double RhoOpt(double p, double K, double sd, double rd, double rf, double t, int CP);
double VegaOpt(double p, double K, double sd, double rd, double rf, double t, int CP);
double ElasticityOpt(double p, double K, double sd, double rd, double rf, double t, int CP);

//add by jinchun 20130913 begin
double DeltaBinomialEuropean(double p, double K, double sd, double rd, double t, int CP);
double GammaBinomialEuropean(double p, double K, double sd, double rd, double t, int CP);
double ThetaBinomialEuropean(double p, double K, double sd, double rd, double t, int CP);
double RhoBinomialEuropean(double p, double K, double sd, double rd, double t, int CP);
double VegaBinomialEuropean(double p, double K, double sd, double rd, double t, int CP);
//add by jinchun 20130913 end
//mod by jinchun 20130913 begin
//double OptionEuropean(double Price ,
//					  double Strike,
//					  double Volatility,
//					  double DomesticRate,
//					  double ForeignRate,
//					  double Expiration,
//					  char OptionType,
//					  char Greek)
double OptionEuropean(double Price , double Strike, double Volatility, double DomesticRate, double ForeignRate, double Expiration, char OptionType, char Greek, char Model)
//mod by jinchun 20130913 end
{
	/*Returns the value or 'greek' of a call or put european option.*/
	
	const int  CP=(OptionType=='C')?1:-1;
	const double    p = Price;
	const double    K = Strike;
	const double    sd = Volatility / 100;
	const double    rd = DomesticRate / 100;
	const double    rf = ForeignRate / 100;
	const double    t = Expiration;    
	if(sd <0 ||(OptionType!='C'&& OptionType!='P'))
    {
		printf("OptionEuropean error: sd=%f OptionType=%c\n",sd,OptionType);
		return OPT_ERROR_CODE;
    }
	
	if(Greek==0)
		Greek=VALUE;
    //add by jinchun 20130913 begin
    if(BS == Model){
    //add by jinchun 20130913 end 
	switch(Greek){
	case VALUE: 
	case PREMIUM:
		return ValueOpt(p, K, sd, rd, rf, t, CP);
	case DELTA:
		return DeltaOpt(p, K, sd, rd, rf, t, CP);
	case GAMMA:
		return GammaOpt(p, K, sd, rd, rf, t, CP);
	case THETA:
		return ThetaOpt(p, K, sd, rd, rf, t, CP);
	case RHODOM:
		return  RhoDomOpt(p, K, sd, rd, rf, t, CP);
	case RHOFOR:
		return RhoForOpt(p, K, sd, rd, rf, t, CP);
	case VEGA:
	case LAMBDA:
	case KAPPA:
		return  VegaOpt(p, K, sd, rd, rf, t, CP);
	case ELASTICIT:
		return ElasticityOpt(p, K, sd, rd, rf, t, CP);
	case RHO:
		return RhoOpt(p, K, sd, rd, rf, t, CP);
	default:
		printf("OptionEuropean error:invalid Greek\n");
		return OPT_ERROR_CODE;
	}
    //add by jinchun 20130913 begin
    }else{
        switch(Greek){
            case VALUE: 
                return ValueBinomialEuropean(p, K, sd, rd, t, CP);
            case DELTA:
                return DeltaBinomialEuropean(p, K, sd, rd, t, CP);
            case GAMMA:
                return GammaBinomialEuropean(p, K, sd, rd, t, CP);
            case THETA:
                return ThetaBinomialEuropean(p, K, sd, rd, t, CP);
            case RHODOM:
                return  RhoBinomialEuropean(p, K, sd, rd, t, CP);
            case VEGA:
                return  VegaBinomialEuropean(p, K, sd, rd, t, CP);
            default:
                printf("OptionEuropean error:invalid Greek\n");
                return OPT_ERROR_CODE;
        }
    }
    //add by jinchun 20130913 end
}


double ValueOpt(double p, double K, double sd, double rd, double rf, double t, int CP){
    //add by jinchun 20130913 begin
    if(K < 0.00001){
        K = 0.00001;
    }
    if(sd < 0.00001){
        sd = 0.00001;
    }
    if(t < 0.00001){
        t = 0.00001;
    }
    //add by jinchun 20130913 end
	const double d1 = (safe_ln(p / K) + t * (rd - rf + 0.5 * sd*sd)) / (sd * sqrt(t));
	const double d2 = d1 - sd * sqrt(t);
	return CP * (p * NormCumDist(CP * d1) / exp(rf * t) - K * NormCumDist(CP * d2) / exp(rd * t));
}
/*
b=rd-rf
r=rd
d1 = ( log(S/X) + (b+sigma*sigma/2)*Time ) / (sigma*sqrt(Time))
d2 = d1 - sigma*sqrt(Time)
if (TypeFlag == "c")
result = S*exp((b-r)*Time)*CND(d1) - X*exp(-r*Time)*CND(d2) 
if (TypeFlag == "p")
result = X*exp(-r*Time)*CND(-d2) - S*exp((b-r)*Time)*CND(-d1) 
*/

double DeltaOpt(double p, double K, double sd, double rd, double rf, double t, int CP){
    //add by jinchun 20130913 begin
    if(K < 0.00001){
        K = 0.00001;
    }
    if(sd < 0.00001){
        sd = 0.00001;
    }
    if(t < 0.00001){
        t = 0.00001;
    }
    //add by jinchun 20130913 end
	const double  d1 = (safe_ln(p / K) + t * (rd - rf + 0.5 * sd*sd)) / (sd * sqrt(t));
    //mod by jinchun 20130913 begin
	//return exp(-rf * t) * CP * NormCumDist(CP * d1);
    return exp(-rd * t) * (NormCumDist(d1) + (CP - 1) / 2);
    //mod by jinchun 20130913 end
}
/*
b=rd-rf
r=rd
d1 = ( log(S/X) + (b+sigma*sigma/2)*Time ) / (sigma*sqrt(Time))
if (TypeFlag == "c") result = exp((b-r)*Time)*CND(d1)
*/

double GammaOpt(double p, double K, double sd, double rd, double rf, double t, int CP){
    //add by jinchun 20130913 begin
    if(K < 0.00001){
        K = 0.00001;
    }
    if(sd < 0.00001){
        sd = 0.00001;
    }
    if(t < 0.00001){
        t = 0.00001;
    }
    if(p < 0.00001){
        p = 0.00001;
    }
    //add by jinchun 20130913 end
	const double  d1 = (safe_ln(p / K) + t * (rd - rf + 0.5 * sd*sd)) / (sd * sqrt(t));
	return exp(-rf * t) * exp(-0.5 * d1*d1) / (p * sd * sqrt(2 * Pi * t));
}
/*
d1 = ( log(S/X) + (b+sigma*sigma/2)*Time ) / (sigma*sqrt(Time))
result = exp((b-r)*Time)*NDF(d1)/(S*sigma*sqrt(Time)) # Call,Put
*/
double ThetaOpt(double p, double K, double sd, double rd, double rf, double t, int CP){
    //add by jinchun 20130913 begin
    if(K < 0.00001){
        K = 0.00001;
    }
    if(sd < 0.00001){
        sd = 0.00001;
    }
    if(t < 0.00001){
        t = 0.00001;
    }
    //add by jin hunc 2013 0913 end
	const double  d1 = (safe_ln(p / K) + t * (rd - rf + 0.5 * sd*sd)) / (sd * sqrt(t));
	const double  d2 = d1 - sd * sqrt(t);
	const double  N_d1 = 1/(exp((d1*d1) / 2)*sqrt(2*Pi));
	const double  Theta1 = -(p*N_d1*sd)/(2*sqrt(t)*exp(rf*t));
    //mod by jinchun 20130913 begin
	//return Theta1+rf*p*exp(-rf*t)*NormCumDist(CP*d1)-CP*rd*K*exp(-rd*t)*NormCumDist(CP*d2);
	return (Theta1 + CP * rd * p * exp(-rf * t) * NormCumDist(CP * d1) - CP * rd * K * exp(-rd * t) * NormCumDist(CP * d2)) / 365;
    //mod by jinchun 20130913 end
}
/*
d1 = ( log(S/X) + (b+sigma*sigma/2)*Time ) / (sigma*sqrt(Time))
Theta1 = -(S*exp((b-r)*Time)*NDF(d1)*sigma)/(2*sqrt(Time))  
if (TypeFlag == "c") result = Theta1 - 
(b-r)*S*exp((b-r)*Time)*CND(+d1) - r*X*exp(-r*Time)*CND(+d2) 
if (TypeFlag == "p") result = Theta1 + 
(b-r)*S*exp((b-r)*Time)*CND(-d1) + r*X*exp(-r*Time)*CND(-d2) 
*/

double RhoDomOpt(double p, double K, double sd, double rd, double rf, double t, int CP){
    //add by jinchun 20130913 begin
    //if(K < 0.00001){
    //    K = 0.00001;
    //}
    //if(sd < 0.00001){
    //    sd = 0.00001;
    //}
    if(t < 0.00001){
        t = 0.00001;
    }
    //add by jinchun 20130913 end
	//const double  d1 = (safe_ln(p / K) + t * (rd - rf + 0.5 * sd*sd)) / (sd * sqrt(t));
	//const double  d2 = d1 - sd * sqrt(t);  
    //mod by jinchun 20130913 begin
	//return -(exp(-(d2*d2) / 2 - rd * t) * K * sqrt(t) / (sqrt(2 * Pi) * sd)) + exp(-(d1*d1) / 2 - rf * t) * p * sqrt(t) / (sqrt(2 * Pi) * sd) + CP * K * t * NormCumDist(CP * d2) / exp(rd * t);
    return -ValueOpt(p, K, sd, rd * 1.01, rf * 1.01, t, CP) * t * 0.01;
	//mod by jinchun 20130913 end
}

double RhoForOpt(double p, double K, double sd, double rd, double rf, double t, int CP){
	const double    d1 = (log(p / K) + t * (rd - rf + 0.5 * sd*sd)) / (sd * sqrt(t));
	const double  d2 = d1 - sd * sqrt(t);
	return exp(-(d2*d2) / 2 - rd * t) * K * sqrt(t) / (sqrt(2 * Pi) * sd) - exp(-(d1*d1) / 2 - rf * t) * p * sqrt(t) / (sqrt(2 * Pi) * sd) - CP * p * t * NormCumDist(CP * d1) / exp(rf * t);
}

double RhoOpt(double p, double K, double sd, double rd, double rf, double t, int CP){
	const double  d1 = (log(p / K) + t * (rd - rf + 0.5 * sd*sd)) / (sd * sqrt(t));
	const double  d2 = d1 - sd * sqrt(t);
	const double CallPut=ValueOpt(p,K,sd,rd,rf,t,CP);
	if (CP == 1) {
		if ((rd-rf) != 0) 
			return t * K * exp(-rd*t)*NormCumDist(d2);
		else 
			return -t * CallPut;
	} 
	else if (CP == -1) {
		if ((rd-rf) != 0) 
			return -t * K * exp(-rd*t)*NormCumDist(-d2);
		else 
			return -t * CallPut;
	}
	else 
		return 0;
}
/*
b=rd-rf
r=rd
d1 = ( log(S/X) + (b+sigma*sigma/2)*Time ) / (sigma*sqrt(Time))
d2 = d1 - sigma*sqrt(Time)
CallPut = GBSOption(TypeFlag, S, X, Time, r, b , sigma)
if (TypeFlag == "c") {
if (b != 0) {result =  Time * X * exp(-r*Time)*CND( d2)} 
else {result = -Time * CallPut } }
if (TypeFlag == "p") {
if (b != 0) {result = -Time * X * exp(-r*Time)*CND(-d2)}
else { result = -Time * CallPut } }
*/

double VegaOpt(double p, double K, double sd, double rd, double rf, double t, int CP){
    //add by jinchun 20130913 begin
    if(K < 0.00001){
        K = 0.00001;
    }
    if(sd < 0.00001){
        sd = 0.00001;
    }
    if(t < 0.00001){
        t = 0.00001;
    }
    //add by jinchun 20130913 end
	const double  d1 = (safe_ln(p / K) + t * (rd - rf + 0.5 * sd*sd)) / (sd * sqrt(t));
	const double  N_d1 = 1/(exp((d1*d1) / 2)*sqrt(2*Pi));
    //mod by jinchun 20130913 begin
	//return p*exp(-rf*t)*N_d1*sqrt(t);
    return p * exp(-rf * t) * N_d1 * sqrt(t) * 0.01;
    //mod by jinchun 20130913 end
}
/*
d1 = ( log(S/X) + (b+sigma*sigma/2)*Time ) / (sigma*sqrt(Time))
result = S*exp((b-r)*Time)*NDF(d1)*sqrt(Time) # Call,Put
*/

double ElasticityOpt(double p, double K, double sd, double rd, double rf, double t, int CP){
	const double d1 = (log(p / K) + (rd - rf) * t) / (sd * sqrt(t)) + 0.5 * sd * sqrt(t);
	const double d2 = (log(p / K) + (rd - rf) * t) / (sd * sqrt(t)) + 0.5 * sd * sqrt(t) - sd * sqrt(t);
	const double d3 = sqrt(2 * Pi * t) * sd;
	return exp(-(d1*d1) / 2 - (d2*d2) / 2) * (CP * exp((d1*d1) / 2 + rf * t) * K - CP * exp((d2*d2) / 2 + rd * t) * p - exp((d1*d1) / 2 + d2*d2 / 2 + rd * t) * p * d3 * NormCumDist(CP * d1)) / (d3 * (-(exp(rd * t) * p * NormCumDist(CP * d1)) + exp(rf * t) * K * NormCumDist(CP * d2)));
}

//add by jinchun 20130913 begin
double ValueBinomialEuropean(double p, double K, double sd, double rd, double t, int CP){
    int i;
    if(sd < 0.00001){
        sd = 0.00001;
    }
    if(t < 0.00001){
        t = 0.00001;
    }
    t = t / g_step;
    double t_sqrt = sqrt(t);
    double u = exp(sd * t_sqrt);
    if(u < 1.00001){
        u = 1.00001;
    }
    double u_sqr = u * u;
    double d = 1 / u;
    double po = (1 - d) / (u - d);
    double q = 1 - po;
    double* f = new double[g_step + 1];
    double* Sn = new double[g_step + 1];
    Sn[0] = p * pow(u, g_step);
    f[0] = CP * (Sn[0] - K);
    if(f[0] < 0){
        f[0] = 0;
    }
    for(i = 0; i < g_step; i++){
        Sn[i+1] = Sn[i] / u_sqr;
        f[i + 1] = CP * (Sn[i + 1] - K);
        if(f[i + 1] < 0){
            f[i + 1] = 0;
        }
    }
    for(i = 0; i < g_step; i++){
        for(int j = 0; j < g_step - i; j++){
            f[j] = exp(-rd * t) * (po * f[j] + q * f[j + 1]);
            Sn[j] /= u;
        }
    }
    double result = f[0];
    delete[] f;
    delete[] Sn;
    return result;
}

double DeltaBinomialEuropean(double p, double K, double sd, double rd, double t, int CP){
    if(p < 0.00001){
        p = 0.00001;
    }
	return (ValueBinomialEuropean(p * 1.001, K, sd, rd, t, CP) - ValueBinomialEuropean(p * 0.999, K, sd, rd, t, CP)) / (p * 0.002);
}

double GammaBinomialEuropean(double p, double K, double sd, double rd, double t, int CP){
    if(p < 0.00001){
        p = 0.00001;
    }
	return (DeltaBinomialEuropean(p * 1.01, K, sd, rd, t, CP) - DeltaBinomialEuropean(p * 0.99, K, sd, rd, t, CP)) / (p * 0.02);
}

double ThetaBinomialEuropean(double p, double K, double sd, double rd, double t, int CP){
    if(t < 0.00001){
        t = 0.00001;
    }
	return (ValueBinomialEuropean(p, K, sd, rd, t * 0.99, CP) - ValueBinomialEuropean(p, K, sd, rd, t * 1.01, CP)) / (t * 0.02 * 365);
}

double RhoBinomialEuropean(double p, double K, double sd, double rd, double t, int CP){
    if(rd < 0.00001){
        rd = 0.00001;
    }
	return (ValueBinomialEuropean(p, K, sd, rd * 1.01, t, CP) - ValueBinomialEuropean(p, K, sd, rd * 0.99, t, CP)) / (rd * 2);
}

double VegaBinomialEuropean(double p, double K, double sd, double rd, double t, int CP){
    if(sd < 0.00001){
        sd = 0.00001;
    }
	return (ValueBinomialEuropean(p, K, sd * 1.001, rd, t, CP) - ValueBinomialEuropean(p, K, sd * 0.999, rd, t, CP)) / (sd * 0.2);
}
//add by jinchun 20130913 end
