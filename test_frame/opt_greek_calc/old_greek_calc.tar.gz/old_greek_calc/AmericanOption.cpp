#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include "Option.h"
#include "distributions.h"

double ValueAmerican(double p , double K , double sd , double rd , double rf , double t , int CP);
double DeltaAmerican(double p , double K , double sd , double rd , double rf , double t , int CP);
double GammaAmerican(double p , double K , double sd , double rd , double rf , double t , int CP);
double ThetaAmerican(double p , double K , double sd , double rd , double rf , double t , int CP);
double RhoDomAmerican(double p , double K , double sd , double rd , double rf , double t , int CP);
double RhoForAmerican(double p , double K , double sd , double rd , double rf , double t , int CP);
double VegaAmerican(double p , double K , double sd , double rd , double rf , double t , int CP);
//add by jinchun 20130913 begin
double ValueBinomialAmerican(double p, double K, double sd, double rd, double t, int CP);
double DeltaBinomialAmerican(double p, double K, double sd, double rd, double t, int CP);
double GammaBinomialAmerican(double p, double K, double sd, double rd, double t, int CP);
double ThetaBinomialAmerican(double p, double K, double sd, double rd, double t, int CP);
double RhoBinomialAmerican(double p, double K, double sd, double rd, double t, int CP);
double VegaBinomialAmerican(double p, double K, double sd, double rd, double t, int CP);
//add by jinchun 20130913 end
//mod by jinchun 20130913 begin
//double OptionAmerican(double Price,
//					  double Strike,
//					  double Volatility,
//					  double DomesticRate,
//					  double ForeignRate,
//					  double Expiration,
//					  char OptionType,
//                      char Greek)
double OptionAmerican(double Price, double Strike, double Volatility, double DomesticRate, double ForeignRate, double Expiration, char OptionType, char Greek, char Model)
//mod by jinchun 20130913 end
{
	/* Returns the value or greeks of a call or put american option.*/
    
	const int  CP=(OptionType=='C')?1:-1;
	const double    p = Price;
	const double    K = Strike;
	const double    sd = Volatility / 100;
	const double    rd = DomesticRate / 100;
	const double    rf = ForeignRate / 100;
	const double    t = Expiration;
	
	if(sd <0 ||(OptionType!='C' && OptionType!='P'))
    {
		printf("OptionAmerican error: sd=%f OptionType=%c\n",sd,OptionType);
		return OPT_ERROR_CODE;
    }
    
	if(Greek==0)
		Greek=VALUE;
    //add by jinchun 20130913 begin
    if(BAW == Model){
    //add by jinchun 20130913 end
	switch(Greek){
	case VALUE: 
	case PREMIUM:
		return ValueAmerican(p, K, sd, rd, rf, t, CP);
	case DELTA:
		return DeltaAmerican(p, K, sd, rd, rf, t, CP);
	case GAMMA:
		return GammaAmerican(p, K, sd, rd, rf, t, CP);
	case THETA:
		return ThetaAmerican(p, K, sd, rd, rf, t, CP);
	case RHODOM:
		return  RhoDomAmerican(p, K, sd, rd, rf, t, CP);
	case RHOFOR:
		return RhoForAmerican(p, K, sd, rd, rf, t, CP);
	case VEGA:
		return  VegaAmerican(p, K, sd, rd, rf, t, CP);
	case LAMBDA:
	case KAPPA:
	default:
		printf("OptionAmerican error:invalid Greek\n");
		return OPT_ERROR_CODE;
	}
    //add by jinchun 20130913 begin
    }else{
        switch(Greek){
            case VALUE: 
                return ValueBinomialAmerican(p, K, sd, rd, t, CP);
            case DELTA:
                return DeltaBinomialAmerican(p, K, sd, rd, t, CP);
            case GAMMA:
                return GammaBinomialAmerican(p, K, sd, rd, t, CP);
            case THETA:
                return ThetaBinomialAmerican(p, K, sd, rd, t, CP);
            case RHODOM:
                return  RhoBinomialAmerican(p, K, sd, rd, t, CP);
            case VEGA:
                return  VegaBinomialAmerican(p, K, sd, rd, t, CP);
            default:
                printf("OptionAmerican error:invalid Greek\n");
                return OPT_ERROR_CODE;
        }
    }
    //add by jinchun 20130913 end
}

/************************************************************
* �������ƣ� ValueAmerican
* ���������� ��BAWģ�ͼ�����ʽ��Ȩ���ۼ�
* ���������� double S ; �ڻ���ǰ�۸�
* ���������� double X ; ��Ȩִ�м�
* ���������� double sigma ; �ڻ��۸񲨶���
* ���������� double rd ; �����޷�������
* ���������� double rf ; �����޷������ʣ����ڱ�����û�б�ʹ�ã�������Ϊ0
* ���������� double T ; ��Ȩ����ʱ�䣬��λ���꣩
* ���������� int CP ; ����=1������=-1��
* �� �� ֵ�� double 
* ����˵���� 
* �޸�����					�汾��		�޸���		�޸�����
* ----------------------------------------------------------
* 2013-02-04 9:14:11		V1.0		��        ��Ϊ��׼BAWģ��
*************************************************************/

double ValueAmerican(double S, double X, double sigma, double rd, double rf, double T, int CP){
    double sigma_sqr;
    double T_sqrt;
	double e_rT;
    double d1;      // Black-scholes-merton��ʽ��d1 ;
    double d2;      // Black-scholes-merton��ʽ��d2 ;
    double RHS;     // ������ʽ���ұ߲��� 
    double b;       // ������ʽ��ʹ�õı���bi;
    double S_star;  // ���ǹ�ʽ�е�S* �� ������Ȩ��ʽ�е�S**;
    double q2_inf;  // ����q2(����󣩡�
    double q2;      
    double M_K;     // ���ǹ�ʽ�е�M/K�Ľ��
    double S_star_inf; // ���ǹ�ʽ�е�S*(�����) �� ������Ȩ��ʽ�е�S**(�����);
    double h2;          
    double dq2;     // ֵΪ1/q2 
    double ret;     // ���ص���Ȩ��ֵ
    double sigma_T_sqrt;
    double E;       // ŷʽ��Ȩ��ֵ
    double A2;      //
    double nd1;     // Black-scholes-merton��ʽ�еĸ����ܶȺ�����Value= 1 / sqrt(2 * Pi) * exp(-d1 * d1 / 2);
    double LHS;     // ������ʽ�е��Ұ벿��
    int step;       // ��������  
	//��ֹ��0
    if(rd < 0.00001){
        rd = 0.00001;
    }
    if(sigma < 0.00001){
        sigma = 0.00001;
    }
    if(T < 0.00001){
        T = 0.00001;
    }
    if(X < 0.00001){
        X = 0.00001;
    }
    sigma_sqr = sigma * sigma;
    T_sqrt = sqrt(T);
    sigma_T_sqrt = sigma * T_sqrt;
    //���㳣�ñ���
    e_rT = exp(-rd * T);
    M_K = 2 * rd / (sigma_sqr * (1 - e_rT));
    q2 = (1 + CP * sqrt(1 + 4 * M_K)) * 0.5;
    q2_inf = (1 + CP * sqrt(1 + 8 * rd / sigma_sqr)) * 0.5;
    if(q2_inf > 0.9999 && q2_inf < 1.0001){
        q2_inf = 1.0001;
    }else if(CP*q2_inf < 0.0001){
        q2_inf = CP*0.0001;
    }

    S_star_inf = X / (1 - 1 / q2_inf);
    h2 = CP * 2 * sigma_T_sqrt * X / (X - S_star_inf);
    //����S*ֵ������
    S_star = X + (S_star_inf - X) * (1 - exp(h2));
    dq2=1 / q2;
    step = 0;
    //ţ�ٵ���������S*
    do{
        d1 = (safe_ln(S_star / X) + T * sigma_sqr * 0.5) / sigma_T_sqrt;
        nd1 = 1 / sqrt(2 * Pi) * exp(-d1 * d1 / 2);
        d2 = d1 - sigma_T_sqrt;
        //ŷʽ��Ȩ�۸�
        E = CP * (S_star * NormCumDist(CP * d1) * e_rT - X * NormCumDist(CP * d2) * e_rT);
        //S*��ⷽ���ұ߶���
        RHS = E + CP * ((1 - e_rT * NormCumDist(CP * d1)) * S_star * dq2);
        //S*��ⷽ����߶���
        LHS = CP * (S_star - X);
        b = e_rT * NormCumDist(d1) * (1 - dq2) + (CP - e_rT * nd1 / sigma_T_sqrt) * dq2;
        if( CP == b ){
           b = CP*0.9999;
        }
        S_star = (X + CP * RHS - CP * b * S_star) / (1 - CP * b);
        step = step + 1;
    }while(!((fabs((LHS - RHS) / X) < 0.00001 && step > 3) || (step > 50) || (S_star < 0)));

    if(S_star < 0.00001){
         S_star = 0.00001;
        }
    //���¼���d1(S)��������ŷʽ��Ȩ�۸�
    d1 = (safe_ln(S / X) + T * sigma_sqr * 0.5) / sigma_T_sqrt;
    d2 = d1 - sigma_T_sqrt;
    E = CP * (S * NormCumDist(CP * d1) * e_rT - X * NormCumDist(CP * d2) * e_rT);

    if (CP * (S - S_star) >= 0){
		ret = CP * (S - X);
	}
	else{
        //d1(S*)��������BAW�е�A2
		d1 = (safe_ln(S_star / X) + T * sigma_sqr * 0.5) / sigma_T_sqrt;
		A2 = CP * (1 - e_rT * NormCumDist(CP * d1)) * S_star * dq2;
        //���¼���d1(S)��������ŷʽ��Ȩ�۸�
		//d1 = (log(S / X) + T * sigma_sqr * 0.5) / sigma_T_sqrt;
		//d2 = d1 - sigma_T_sqrt;
		//E = CP * (S * NormCumDist(CP * d1) * e_rT - X * NormCumDist(CP * d2) * e_rT);

		ret = E + A2 * pow((S / S_star), q2);
	}
    //��ʽ��Ȩ�������ŷʽ��Ȩ��������С��ŷʽ��Ȩ����ȡŷʽ��Ȩ��
	if(ret < E){
		ret = E;
    }
	return ret;
}




double  DeltaAmerican(double p , double K , double sd , double rd , double rf , double t , int CP){
    //add by jinchun 2013.4.18 begin
    if(p < 0.00001){
        p = 0.00001;
    }
    //add by jinchun 2013.4.18 end
	return (ValueAmerican(p * 1.001, K, sd, rd, rf, t, CP) -
		ValueAmerican(p * 0.999, K, sd, rd, rf, t, CP)) / (p * 0.002);
}

double GammaAmerican(double p , double K , double sd , double rd , double rf , double t , int CP){
    //add by jinchun 2013.4.18 begin
    if(p < 0.00001){
        p = 0.00001;
    }
    //add by jinchun 2013.4.18 end
	return (DeltaAmerican(p * 1.01, K, sd, rd, rf, t, CP) - 
		DeltaAmerican(p * 0.99, K, sd, rd, rf, t, CP)) / (p * 0.02);
}

double ThetaAmerican(double p , double K , double sd , double rd , double rf , double t , int CP){
    //add by jinchun 2013.4.18 end
    if(t < 0.00001){
        t = 0.00001;
    }
    //add by jinchun 2013.4.18 end
    //mod by jinchun 2013.4.18 begin
	//return (ValueAmerican(p,K,sd,rd,rf,t * 1.01,CP) - 

	//	ValueAmerican(p,K,sd,rd,rf,t * 0.99,CP)) / (t * 0.02);

	return (ValueAmerican(p, K, sd, rd, rf, t * 0.99, CP) - 
		ValueAmerican(p, K, sd, rd, rf, t * 1.01, CP)) / (t * 0.02 * 365);
    //mod by jinchun 2013.4.18 end
}

double RhoDomAmerican(double p , double K , double sd , double rd , double rf , double t , int CP){
    //add by jinchun 2013.4.18 begin
    if(rd < 0.00001){
        rd = 0.00001;
    }
    //add by jinchun 2013.4.18 end
    //mod by jinchun 2013.4.18 begin
    //return (ValueAmerican(p,K,sd,rd * 1.01,rf,t,CP) - 

    //    ValueAmerican(p,K,sd,rd * 0.99,rf,t,CP)) / (rd * 0.02);
	return (ValueAmerican(p, K, sd, rd * 1.01, rf, t, CP) - ValueAmerican(p, K, sd, rd * 0.99, rf, t, CP)) / (rd * 2);
    //mod by jinchun 2013.4.18 end
}

double RhoForAmerican(double p , double K , double sd , double rd , double rf , double t , int CP){
	return  (ValueAmerican(p, K, sd, rd, rf * 1.01, t, CP) -
		ValueAmerican(p, K, sd, rd, rf * 0.99, t, CP)) / (rf * 0.02);
}

double VegaAmerican(double p , double K , double sd , double rd , double rf , double t , int CP){
    //add by jinchun 2013.4.18 begin
    if(sd < 0.00001){
        sd = 0.00001;
    }
    //add by jinchun 2013.4.18 end
    //mod by jinchun 2013.4.18 begin
    //return (ValueAmerican(p,K,sd * 1.001,rd,rf,t,CP) - 

	//    ValueAmerican(p,K,sd * 0.999,rd,rf,t,CP)) / (sd * 0.002);

	return (ValueAmerican(p, K, sd * 1.001, rd, rf, t, CP) - 
		ValueAmerican(p, K, sd * 0.999, rd, rf, t, CP)) / (sd * 0.2);
    //mod by jinchun 2013.4.18 end
}

/*
�˺�����ţ�ٵ�������BAWģ�ͷ�����ʽ��Ȩ������������

����˵����
S: �����۸񣬼��ڻ��۸�
X: ��Ȩִ�м۸�
p: ��Ȩ�ĵ�ǰ�۸�
rd: �����޷������ʣ������M(M���ꡢ��N�¡����¡�����)��Ϣ
rf: �����޷������ʣ������M(M���ꡢ��N�¡����¡�����)��Ϣ
T: ���뵽���յ�ʣ��ʱ�䣬��MΪ��λ
CP: ��Ȩ���࣬��ѡֵΪ 'C':������Ȩ(Call Option) 'P':������Ȩ(Put Option)

����ֵ˵����
�۸���p����Ȩ������������
*/		
//mod by jinchun 20130913 begin
double OptionImpliedVolatility(double S, double X, double p, double rd, double rf, double T, char CP, char Model)
//mod by jinchun 20130913 end
{
    double p_estimated;
    double sigma;
    double p_diff;
    double sigma_new;
    double value_opt;
    int step;
    int binom_step;
    rd = rd / 100;
	sigma = 0.2;
    //�����Ȩ�۸���ͣ������ں���ֵ��ֱ��ʹ������ں���ֵ�����������������
    switch(Model){
        case BAW:
            value_opt = ValueAmerican(S, X, 0, rd, rd, T, CP == 'C' ? 1 : -1);
            break;
        case BS:
            value_opt = ValueOpt(S, X, 0, rd, rd, T, CP == 'C' ? 1 : -1);
            break;
        case BINOMIAL_AMERICAN:
            value_opt = ValueBinomialAmerican(S, X, 0, rd, T, CP == 'C' ? 1 : -1);
            break;
        default:
            value_opt = ValueBinomialEuropean(S, X, 0, rd, T, CP == 'C' ? 1 : -1);
    }
    if(p < value_opt){
        p = value_opt;
    }
    //add by jinchun 20130913 begin
    switch(Model){
        case BAW:
    //add by jinchun 20130913 end
    p_estimated = ValueAmerican(S, X, sigma, rd, rd, T, CP == 'C' ? 1 : -1);
    //add by jinchun 20130913 begin
            break;
        case BS:
            p_estimated = ValueOpt(S, X, sigma, rd, rd, T, CP == 'C' ? 1 : -1);
            break;
        case BINOMIAL_AMERICAN:
            p_estimated = ValueBinomialAmerican(S, X, sigma, rd, T, CP == 'C' ? 1 : -1);
            break;
        default:
            p_estimated = ValueBinomialEuropean(S, X, sigma, rd, T, CP == 'C' ? 1 : -1);
    }
    //add by jinchun 20130913 end
    //ȷ��sigma�����ޣ�ÿ������һ����ֱ�����붨�۹�ʽ������С��Ԥ��ֵ
    while(p_estimated < p){
        if(sigma >= 5){
            return 500;
        }
        sigma = sigma * 2;
        if(sigma >= 5){
            sigma = 5;
        }
        //add by jinchun 20130913 begin
        switch(Model){
            case BAW:
        //add by jinchun 20130913 end
        p_estimated = ValueAmerican(S, X, sigma, rd, rd, T, CP == 'C' ? 1 : -1);
        //add by jinchun 20130913 begin
                break;
            case BS:
                p_estimated = ValueOpt(S, X, sigma, rd, rd, T, CP == 'C' ? 1 : -1);
                break;
            case BINOMIAL_AMERICAN:
                p_estimated = ValueBinomialAmerican(S, X, sigma, rd, T, CP == 'C' ? 1 : -1);
                break;
            default:
                p_estimated = ValueBinomialEuropean(S, X, sigma, rd, T, CP == 'C' ? 1 : -1);
        }
        //add by jinchun 20130913 end

    }
    p_diff = p_estimated - p;
    step = 0;
    //������ֵ�ﵽԤ��������0.00001ʱֹͣ����
    while(fabs(p_diff) > 0.00001 && step < 50){
        step++;
        //add by jinchun 20130913 begin
        switch(Model){
            case BAW:
        //add by jinchun 20130913 end
        sigma_new = sigma - p_diff / (p_estimated - ValueAmerican(S, X, sigma - 0.0001, rd, rd, T, CP == 'C' ? 1 : -1)) * 0.0001;
        //add by jinchun 20130913 begin
                break;
            case BS:
                sigma_new = sigma - p_diff / (p_estimated - ValueOpt(S, X, sigma - 0.0001, rd, rd, T, CP == 'C' ? 1 : -1)) * 0.0001;
                break;
            case BINOMIAL_AMERICAN:
                sigma_new = sigma - p_diff / (p_estimated - ValueBinomialAmerican(S, X, sigma - 0.0001, rd, T, CP == 'C' ? 1 : -1)) * 0.0001;
                break;
            default:
                sigma_new = sigma - p_diff / (p_estimated - ValueBinomialEuropean(S, X, sigma - 0.0001, rd, T, CP == 'C' ? 1 : -1)) * 0.0001;
        }
        //add by jinchun 20130913 end
        if(sigma_new < 0){
            sigma_new = sigma / 2;
        }
        //add by jinchun 20130913 begin
        switch(Model){
            case BAW:
        //add by jinchun 20130913 end
        p_estimated = ValueAmerican(S, X, sigma_new, rd, rd, T, CP == 'C' ? 1 : -1);
        //add by jinchun 20130913 begin
                break;
            case BS:
                p_estimated = ValueOpt(S, X, sigma_new, rd, rd, T, CP == 'C' ? 1 : -1);
                break;
            case BINOMIAL_AMERICAN:
                p_estimated = ValueBinomialAmerican(S, X, sigma_new, rd, T, CP == 'C' ? 1 : -1);
                break;
            default:
                p_estimated = ValueBinomialEuropean(S, X, sigma_new, rd, T, CP == 'C' ? 1 : -1);
        }
        //add by jinchun 20130913 end
        //��ֹţ�ٵ�������������ʱ���ö��ַ�ȷ���µ�sigma����ֵ
        binom_step = 0;
        while(p_estimated < p){
            //����50�����޷���Сsigma����ֱ�ӷ������һ����Чsigma
            if(binom_step > 50){
                return sigma * 100;
            }
            sigma_new = (sigma_new + sigma) * 0.5;
            //add by jinchun 20130913 begin
            switch(Model){
                case BAW:
            //add by jinchun 20130913 end
            p_estimated = ValueAmerican(S, X, sigma_new, rd, rd, T, CP == 'C' ? 1 : -1);
            //add by jinchun 20130913 begin
                    break;
                case BS:
                    p_estimated = ValueOpt(S, X, sigma_new, rd, rd, T, CP == 'C' ? 1 : -1);
                    break;
                case BINOMIAL_AMERICAN:
                    p_estimated = ValueBinomialAmerican(S, X, sigma_new, rd, T, CP == 'C' ? 1 : -1);
                    break;
                default:
                    p_estimated = ValueBinomialEuropean(S, X, sigma_new, rd, T, CP == 'C' ? 1 : -1);
            }
            //add by jinchun 20130913 end
            binom_step++;
        }
        sigma = sigma_new;
        p_diff = p_estimated - p;
    }
    return (sigma > 5 ? 5 : sigma) * 100;
}

//add by jinchun 20130913 begin
double ValueBinomialAmerican(double p, double K, double sd, double rd, double t, int CP){
    int i;
    if(sd < 0.00001){
        sd = 0.00001;
    }
    if(t < 0.00001){
        t = 0.00001;
    }
    t = t / g_step;
    double t_sqrt = sqrt(t);
    double u = exp(sd * t_sqrt);
    if(u < 1.00001){
        u = 1.00001;
    }
    double u_sqr = u * u;
    double d = 1 / u;
    double po = (1 - d) / (u - d);
    double q = 1 - po;
    double* f = new double[g_step + 1];
    double* Sn = new double[g_step + 1];
    Sn[0] = p * pow(u, g_step);
    f[0] = CP * (Sn[0] - K);
    if(f[0] < 0){
        f[0] = 0;
    }
    for(i = 0; i < g_step; i++){
        Sn[i+1] = Sn[i] / u_sqr;
        f[i + 1] = CP * (Sn[i + 1] - K);
        if(f[i + 1] < 0){
            f[i + 1] = 0;
        }
    }
    for(i = 0; i < g_step; i++){
        for(int j = 0; j < g_step - i; j++){
            f[j] = exp(-rd * t) * (po * f[j] + q * f[j + 1]);
            Sn[j] /= u;
            if(f[j] < CP * (Sn[j] - K)){
                f[j] = CP * (Sn[j] - K);
            }
        }
    }
    double result = f[0];
    delete[] f;
    delete[] Sn;
    return result;
}

double DeltaBinomialAmerican(double p, double K, double sd, double rd, double t, int CP){
    if(p < 0.00001){
        p = 0.00001;
    }
	return (ValueBinomialAmerican(p * 1.001, K, sd, rd, t, CP) - ValueBinomialAmerican(p * 0.999, K, sd, rd, t, CP)) / (p * 0.002);
}

double GammaBinomialAmerican(double p, double K, double sd, double rd, double t, int CP){
    if(p < 0.00001){
        p = 0.00001;
    }
	return (DeltaBinomialAmerican(p * 1.01, K, sd, rd, t, CP) - DeltaBinomialAmerican(p * 0.99, K, sd, rd, t, CP)) / (p * 0.02);
}

double ThetaBinomialAmerican(double p, double K, double sd, double rd, double t, int CP){
    if(t < 0.00001){
        t = 0.00001;
    }
	return (ValueBinomialAmerican(p, K, sd, rd, t * 0.99, CP) - ValueBinomialAmerican(p, K, sd, rd, t * 1.01, CP)) / (t * 0.02 * 365);
}

double RhoBinomialAmerican(double p, double K, double sd, double rd, double t, int CP){
    if(rd < 0.00001){
        rd = 0.00001;
    }
	return (ValueBinomialAmerican(p, K, sd, rd * 1.01, t, CP) - ValueBinomialAmerican(p, K, sd, rd * 0.99, t, CP)) / (rd * 2);
}

double VegaBinomialAmerican(double p, double K, double sd, double rd, double t, int CP){
    if(sd < 0.00001){
        sd = 0.00001;
    }
	return (ValueBinomialAmerican(p, K, sd * 1.001, rd, t, CP) - ValueBinomialAmerican(p, K, sd * 0.999, rd, t, CP)) / (sd * 0.2);
}
//add by jinchun 20130913 end
