// chuaiGM's test cpp file
// environment: cygwin(win32) HPUX Ubuntu(linux)

///////////////*****include & define*****///////////////
#if 0
#define WIN_32                // win32 Environment
#else
#define LINUX_UNIX            // Linux & Unix Environment
#endif

#define VAR_NAME(x) #x
#define PRINT_VAR(x) \
        cout<<"-->> "<<VAR_NAME(x)<<" = "<<x<<endl;

// Win32 Include
#ifdef WIN_32
//#include "windows.h"
#endif
// Linux & Unix Include
#ifdef LINUX_UNIX
#include <sys/time.h>
#include <unistd.h>
#endif

// C++ standard header
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <vector>
#include <typeinfo>
#include <cmath>
#include <string.h>
// include class
#include "file_op.h"
#include "global_def.h"

// biz need
#include "Option.h"

using namespace std;

///////////////*****const & global*****///////////////

// Define some Fixed
const char in_file[] = "input_param.csv";
const char OutfileName[] = "Outfile_ChuaiTest.txt";

const double _PRICE_MAX = 999999999;
const double _DATE_MAX = 29999999;

// 关键字的列，列表
const string keyword_list[] = {" call_put",
                               " subject_price",
                               " option_strike",
                               " option_premium",
                               " now_date",
                               " expire_date",
                               " no_risk_rate"};

// 原计算用全局变量
int g_step = 50;

///////////////*****Functions*****///////////////
//
// Func | Safe scanf
void absorbEOF()
{
    int c;
    while((c=getchar())!='\n'&&c!= EOF){}
}

// 校验某一个列的关键字, 下面 i 从0开始数列数
bool check_a_keyword(int i, string first_line)
{
    // 注意从0开始
    //              |find(",") == 4
    //              V
    //      0 1 2 3 4 5 6 7 8 9
    //      a b c d ,   d e   
    static size_t last_pos; // 静态变量记录上一次的字符位置
    static size_t i_pos;    // 静态变量记录当前字符位置
    if(i == 0)
    {
        last_pos = 0;
        i_pos = -1;
    }
    last_pos = i_pos+1;
    i_pos = first_line.find("," ,last_pos);
    string kw = first_line.substr(last_pos, i_pos-last_pos);
    if(kw != keyword_list[i]) {
        cout<<"key word "<<i+1<<" = "<<kw<<" !="<<keyword_list[i]<<endl;
        return false;
    }
    return true;
}
/*

// 对一个计算输入结构赋值
bool fill_input_param(int i, string this_line, greek_calc_input input_para)
{
// 将两个词组成一个结构体变量
#define FORM_STRUCT_VAR(st,var) (#st.##var)
    static size_t last_pos;
    static size_t i_pos;
    if(i == 0)
    {
        last_pos = 0;
        i_pos = -1;
    }
    last_pos = i_pos+1;
    i_pos = this_line.find("," ,last_pos);
    string kw = this_line.substr(last_pos, i_pos-last_pos);
    // 萃取结构体中的类型
    cout<<typeid(FORM_STRUCT_VAR(input_para,keyword_list[i])).name()<<endl;
    exit(-1);

    if(kw != keyword_list[i]) {
        cout<<"key word "<<i+1<<" = "<<kw<<" !="<<keyword_list[i]<<endl;
        return false;
    }

    return true;
}
*/

// 去除string 头尾空格
std::string& trim(std::string &s)
{
    if (s.empty())
    {
        return s;
    }

    s.erase(0,s.find_first_not_of(" "));
    s.erase(s.find_last_not_of(" ") + 1);
    return s;
}

// 将数字型的年月日做差，算出实际相差天数，并按年转化为小数
double per_days_a_year(int begin, int end)
{
    struct tm bg;
    struct tm ed;
    memset(&bg, 0, sizeof(bg));
    memset(&ed, 0, sizeof(ed));

    bg.tm_year = begin/10000 - 1900;
    bg.tm_mon  = begin%10000/100 - 1;
    bg.tm_mday = begin%100;

    ed.tm_year = end/10000 - 1900;
    ed.tm_mon  = end%10000/100 - 1;
    ed.tm_mday = end%100;

    //cout<<bg.tm_year<<"-"<<bg.tm_mon<<"-"<<bg.tm_mday<<endl;
    //cout<<ed.tm_year<<"-"<<ed.tm_mon<<"-"<<ed.tm_mday<<endl;
    /*
    // 注意tm中变量的定义
    struct tm test;
    memset(&test, 0, sizeof(test));
    test.tm_year = 1970-1900;
    test.tm_mon  = 0;
    test.tm_mday = 1;
    cout<<mktime(&test)<<endl;
    */
    //cout<<mktime(&ed)<<endl;
    //cout<<mktime(&bg)<<endl;
    double i_days = abs(difftime(mktime(&ed),mktime(&bg))/(60*60*24));
    cout<<"i_days = "<<i_days<<endl;

    return i_days/365.0;
}

///////////////*****Main() Func*****///////////////
// main in legend
int main(int argc, char *argv[])
{
    printf("\n[Date= %s]\n", __DATE__);
    //////////////////////////////////////////////////////////////////////////
    printf("\n************chuaiTest-Begin************\n\n");
    std::cout<<"old_opt_greek_calc -- method from jc"<<std::endl<<std::endl;
    //////////////////////////////////////////////////////////////////////////
    
    // 获取关键字的数量, 通过sizeof的技巧
    size_t kw_num = sizeof(keyword_list)/sizeof(keyword_list[0]);

    fstream input_file;
    input_file.open(in_file);//打开文件
    if( ! input_file.is_open())
    {
        cout<<"can not open "<<in_file<<" file!"<<endl;
        return false;
    }
    int now_line=0;// 行计数
    string a_line;
    while(getline(input_file,a_line))//循环读取每一行
    {
        now_line++;

        // 校验第一行的关键字数据
        if(now_line == 1)    //第一行
        {
            for(int i=0;i<5;++i)
            {
                if( !check_a_keyword(i,a_line))
                {
                    exit(-1);
                }
            }
            cout<<kw_num<<" key words checked in ["<<in_file<<"]"<<endl;
        }
        else
        {
            cout<<endl<<"input_param:"<<now_line-1<<"--------------------"<<endl;
            greek_calc_input input_para;

            size_t last_pos = 0;
            size_t i_pos = 0;

            i_pos = a_line.find("," ,last_pos);
            string kw_1 = a_line.substr(last_pos, i_pos-last_pos);
            //cout<<"i_pos="<<i_pos<<endl;
            char call_put = trim(kw_1).c_str()[0];
            if(call_put == 'C' || call_put == 'P' || call_put == 'c' || call_put == 'p') {
                input_para.call_put = call_put;
                cout<<"<<-- "<<"call_put = "<<call_put<<endl;
            } else {
                cout<<"line:"<<now_line<<" call_put = "<<call_put<<"error!"<<endl;
                exit(-1);
            }
            last_pos = i_pos+1;
            i_pos = a_line.find("," ,last_pos);
            string kw_2 = a_line.substr(last_pos, i_pos-last_pos);
            double subject_price = stod(kw_2);
            if(subject_price > 0 && subject_price < _PRICE_MAX) {
                input_para.subject_price= subject_price;
                cout<<"<<-- "<<"subject_price = "<<subject_price<<endl;
            } else {
                cout<<"line:"<<now_line<<" subject_price = "<<subject_price<<"error!"<<endl;
                exit(-1);
            }
            last_pos = i_pos+1;
            i_pos = a_line.find("," ,last_pos);
            string kw_3 = a_line.substr(last_pos, i_pos-last_pos);
            double option_strike = stod(kw_3);
            if(option_strike > 0 && option_strike < _PRICE_MAX) {
                input_para.option_strike = option_strike;
                cout<<"<<-- "<<"option_strike = "<<option_strike<<endl;
            } else {
                cout<<"line:"<<now_line<<" option_strike = "<<option_strike<<"error!"<<endl;
                exit(-1);
            }
            last_pos = i_pos+1;
            i_pos = a_line.find("," ,last_pos);
            string kw_4 = a_line.substr(last_pos, i_pos-last_pos);
            double option_premium = stod(kw_4);
            if(option_premium > 0 && option_premium < _PRICE_MAX) {
                input_para.option_premium = option_premium;
                cout<<"<<-- "<<"option_premium = "<<option_premium<<endl;
            } else {
                cout<<"line:"<<now_line<<" option_premium = "<<option_premium<<"error!"<<endl;
                exit(-1);
            }
            last_pos = i_pos+1;
            i_pos = a_line.find("," ,last_pos);
            string kw_5 = a_line.substr(last_pos, i_pos-last_pos);
            int now_date = stoi(kw_5);
            if(now_date > 0 && now_date < _DATE_MAX) {
                input_para.now_date = now_date;
                cout<<"<<-- "<<"now_date    = "<<now_date<<endl;
            } else {
                cout<<"line:"<<now_line<<" now_date = "<<now_date<<"error!"<<endl;
                exit(-1);
            }
            last_pos = i_pos+1;
            i_pos = a_line.find("," ,last_pos);
            string kw_6 = a_line.substr(last_pos, i_pos-last_pos);
            int expire_date = stoi(kw_6);
            if(expire_date > 0 && expire_date < _DATE_MAX) {
                input_para.expire_date = expire_date;
                cout<<"<<-- "<<"expire_date = "<<expire_date<<endl;
            } else {
                cout<<"line:"<<now_line<<" expire_date = "<<expire_date<<"error!"<<endl;
                exit(-1);
            }
            last_pos = i_pos+1;
            i_pos = a_line.find("," ,last_pos);
            string kw_7 = a_line.substr(last_pos, i_pos-last_pos);
            double rate = stod(kw_7);
            if(rate > 0 && rate <100) {
                input_para.no_risk_rate = rate;
                cout<<"<<-- "<<"no_risk_rate = "<<rate<<endl;
            } else {
                cout<<"line:"<<now_line<<" no_risk_rate = "<<rate<<"error!"<<endl;
                exit(-1);
            }

            cout<<">> "<<"calc_output:"<<now_line-1<<"--------------------"<<endl;
            // 调用计算
            // 1. 时间
            input_para.T = per_days_a_year(input_para.now_date, input_para.expire_date);
            cout<<"-->> "<<"T = "<<input_para.T<<endl;
            // 2. 波动率
            input_para.volatility = OptionImpliedVolatility(input_para.subject_price,
                                                            input_para.option_strike,
                                                            input_para.option_premium,
                                                            input_para.no_risk_rate,
                                                            input_para.no_risk_rate,
                                                            input_para.T,
                                                            input_para.call_put,
                                                            BAW
                                                            );

            cout<<"-->> "<<"volatility = "<<input_para.volatility<<endl;
            // 3. 理论价
            double theo_price = OptionAmerican(input_para.subject_price,
                                               input_para.option_strike,
                                               input_para.volatility,
                                               input_para.no_risk_rate,
                                               input_para.no_risk_rate,
                                               input_para.T,
                                               input_para.call_put,
                                               VALUE,
                                               BAW
                                               );
            PRINT_VAR(theo_price);

            cout<<">> "<<"greek :"<<"--------------------"<<endl;
            // 1.
            double delta = OptionAmerican(input_para.subject_price,
                                               input_para.option_strike,
                                               input_para.volatility,
                                               input_para.no_risk_rate,
                                               input_para.no_risk_rate,
                                               input_para.T,
                                               input_para.call_put,
                                               DELTA,
                                               BAW
                                               );
            PRINT_VAR(delta);
            // 2.
            double gamma = OptionAmerican(input_para.subject_price,
                                               input_para.option_strike,
                                               input_para.volatility,
                                               input_para.no_risk_rate,
                                               input_para.no_risk_rate,
                                               input_para.T,
                                               input_para.call_put,
                                               GAMMA,
                                               BAW
                                               );
            PRINT_VAR(gamma);
            // 3.
            double vega = OptionAmerican(input_para.subject_price,
                                               input_para.option_strike,
                                               input_para.volatility,
                                               input_para.no_risk_rate,
                                               input_para.no_risk_rate,
                                               input_para.T,
                                               input_para.call_put,
                                               VEGA,
                                               BAW
                                               );
            PRINT_VAR(vega );
            // 4.
            double theta = OptionAmerican(input_para.subject_price,
                                               input_para.option_strike,
                                               input_para.volatility,
                                               input_para.no_risk_rate,
                                               input_para.no_risk_rate,
                                               input_para.T,
                                               input_para.call_put,
                                               THETA,
                                               BAW
                                               );
            PRINT_VAR(theta);
            // 5.
            double rho = OptionAmerican(input_para.subject_price,
                                               input_para.option_strike,
                                               input_para.volatility,
                                               input_para.no_risk_rate,
                                               input_para.no_risk_rate,
                                               input_para.T,
                                               input_para.call_put,
                                               RHODOM,
                                               BAW
                                               );
            PRINT_VAR(rho  );

            
        }
    }
    input_file.close();
   

#if 0
    // safty method to absorb scanf buffer
    int i,c;
    while (1)
    {
        printf("input:");
        if(scanf("%d",&i)!=EOF)
        {
            while((c=getchar())!='\n'&&c!= EOF){}
        }
        printf("out:%d\n",i);
        //i here hold the last value
    }
#endif
#if 0
    // safty method to absorb cin buffer
    int i;
    while(1)
    {
        cout<<"input:";
        cin>>i;
        cin.clear();
        cin.ignore( std::numeric_limits<std::streamsize>::max( ), '\n' );
        cout<<"out:"<<i<<endl;
        //i here hold the last value
    }
#endif

    //////////////////////////////////////////////////////////////////////////
    printf("\n");
    printf("\n************chuaiTest- End ************\n\n");
    
}

