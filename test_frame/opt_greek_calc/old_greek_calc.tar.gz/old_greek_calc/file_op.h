#include <iostream>
#include <string>
#include <fstream>

const std::streamsize r_buf_len = 512;

//                            这个文件        ,    这一行   ,   这行数据
static bool read_a_line(const char* file_path, int line_num, std::string &line)
{
    std::fstream input_file;
    input_file.open(file_path);//打开文件
    if( ! input_file.is_open())
    {
        std::cout<<"can not open "<<file_path<<" file!"<<std::endl;
        return false;
    }
    char tmp[r_buf_len]="";
    int now_line=0;// 行计数
    while(!input_file.eof())//循环读取每一行
    {
        now_line++;
        if(now_line == line_num) {
            input_file.getline(tmp, r_buf_len); //读取这行的前XX字符
            std::string a_line(tmp);
            line = a_line;
            input_file.close();
            return true;
        }
    }
    input_file.close();
    return false;
}


