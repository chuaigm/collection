#include<math.h>
#include<stdlib.h>
#include<float.h>
#include "distributions.h"
#define  b1  0.31938153
#define  b2  -0.356563782
#define  b3  1.781477937
#define  b4  -1.821255978
#define  b5  1.330274429
#define  ab  0.2316419

double NormCumDist(double Z)
{  
  /* Returns the cumulative normal distribution function.*/
  double K = 1 / (1 + ab * fabs(Z));
  /*  double Temp= b1 * K + b2 * pow(K ,2) + b3 * pow(K,3) + b4 * pow(K,4) + b5 * pow(K ,5); */
  double Temp=(((((b5*K+b4)*K)+b3)*K+b2)*K+b1)*K;
  Temp = 1 - (1 / sqrt(2 * Pi)) * exp(-fabs(Z)*fabs(Z) / 2) * Temp;
  if(Z > 0)
    return Temp;
  else
    return (1 - Temp);
}

 double safe_ln(double x)
{
	return ( x>0 ) ? log(x) : (-DBL_MAX);
}

